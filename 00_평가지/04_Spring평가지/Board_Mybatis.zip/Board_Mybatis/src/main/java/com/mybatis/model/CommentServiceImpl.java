package com.mybatis.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mybatis.dto.CommentDTO;
import com.mybatis.mapper.BoardMapper;
import com.mybatis.mapper.CommentMapper;

@Service
public class CommentServiceImpl implements CommentService {

	@Autowired
	CommentMapper mapper;

	@Autowired
	BoardMapper bmapper;

	@Transactional
	@Override
	public void insert(CommentDTO comment) {
		mapper.insert(comment); // ��� �߰�
		bmapper.updateReplyCnt(comment.getBnum(), 1); // reply cnt ����
	}

	@Override
	public List<CommentDTO> getList(int bnum) {

		return mapper.getList(bnum);
	}

	@Override
	public void delete(int cnum) {
		// comment mapper�� ����ؼ� bnum �����;��Ѵ�.
		int bnum = mapper.read(cnum).getBnum();
		// �θ�ۿ� �ش��ϴ� ��� �� ����
		bmapper.updateReplyCnt(bnum, -1);
		mapper.delete(cnum);

	}

}
