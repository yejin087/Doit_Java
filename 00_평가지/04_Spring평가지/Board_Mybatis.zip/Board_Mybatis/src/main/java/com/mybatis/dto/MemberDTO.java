package com.mybatis.dto;

import lombok.Data;

@Data
public class MemberDTO {
	private String id;
	private String name;
	private String password;
	private String addr;
	private String regdate;

}
