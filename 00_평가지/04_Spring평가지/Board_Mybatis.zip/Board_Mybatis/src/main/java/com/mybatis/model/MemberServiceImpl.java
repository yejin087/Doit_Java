package com.mybatis.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mybatis.dto.MemberDTO;
import com.mybatis.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberMapper mapper;

	@Override
	public void join(MemberDTO member) {
		mapper.join(member);

	}

	@Override
	public int idCheck(String id) {

		return mapper.idCheck(id);
	}

	@Override
	public MemberDTO loginCheck(String id) {

		return mapper.loginCheck(id);
	}

	@Override
	public int updateAcc(MemberDTO member) {

		return mapper.updateAcc(member);

	}

	@Override
	public int deleteAcc(String id) {
		return mapper.deleteAcc(id);

	}

}
