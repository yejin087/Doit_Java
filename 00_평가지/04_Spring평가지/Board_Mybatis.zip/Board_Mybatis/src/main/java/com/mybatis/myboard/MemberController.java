package com.mybatis.myboard;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mybatis.dto.MemberDTO;
import com.mybatis.model.MemberService;

@RequestMapping("/member/*") // controller ã�� ��
@Controller
public class MemberController {

	@Autowired
	MemberService service;

	@GetMapping("join")
	public String join() {
		return "member/join"; // view ã�� ��
	}

	@PostMapping("join")
	@ResponseBody
	public String join(@RequestBody MemberDTO member) {
		int cnt = service.idCheck(member.getId());
		if (cnt != 0)
			return "fail";

		service.join(member);
		return "success";
	}

	@GetMapping("idcheck")
	@ResponseBody
	public int idcheck(String id) {
		return service.idCheck(id);
	}

	@GetMapping("login")
	public String login() {
		return "member/login";
	}

	@PostMapping("login")
	@ResponseBody
	public String login(String id, String pwd, HttpSession session) {
		String result = "";
		MemberDTO member = service.loginCheck(id);

		if (member != null) {
			if (pwd.equals(member.getPassword())) {
				result = "success";
				session.setAttribute("sMember", member);
			} else
				result = "check password";

		} else {
			result = "no";
		}

		return result;

	}

	@GetMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "member/login";
	}

	@GetMapping("update")
	public String update(HttpSession session, Model model) {
		MemberDTO member = (MemberDTO) session.getAttribute("sMember");
		model.addAttribute("member", member);
		return "member/update";
	}

	@PutMapping("update")
	@ResponseBody
	public String update(@RequestBody MemberDTO member, HttpSession session) {
		if (service.updateAcc(member) > 0) {
			session.setAttribute("sMember", member);
			return "success";
		}
		return "fail";
	}

	@DeleteMapping("delete")
	@ResponseBody
	public String delete(HttpSession session) {
		String id = ((MemberDTO) session.getAttribute("sMember")).getId();
		session.invalidate();
		if (service.deleteAcc(id) > 0)
			return "success";

		return "fail";
	}
}
