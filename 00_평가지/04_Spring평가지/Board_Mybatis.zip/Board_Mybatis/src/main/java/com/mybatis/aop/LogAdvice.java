package com.mybatis.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.java.Log;

@Aspect
@Log
@Component
public class LogAdvice {

	// BoardService* �� ����Ǳ� ���� ���� �Լ�
	@Before("execution(* com.myboard.model.BoardService*.*(..))")
	public void logBefore() {
		log.info("====");
	}

	// �Ź� ����
	@Around("execution(* com.myboard.model.BoardService*.*(..))")
	public Object logTime(ProceedingJoinPoint pip) {
		long start = System.currentTimeMillis();
		log.info("Target : " + pip.getTarget());
		log.info("Param : " + Arrays.toString(pip.getArgs()));
		Object result = null;

		try {
			pip.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}

		long end = System.currentTimeMillis();
		log.info("start : " + start);
		log.info("end : " + end);
		log.info("Time : " + (end - start));
		return result;
	}
}
