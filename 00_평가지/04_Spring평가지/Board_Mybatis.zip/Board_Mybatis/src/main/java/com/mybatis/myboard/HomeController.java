package com.mybatis.myboard;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.mybatis.model.BoardService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	@Autowired
	BoardService service;

	@GetMapping({ "/" }) // root, list url������ ����
	public String index() {

		return "redirect:/board/";
	}

}
