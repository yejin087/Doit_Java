package com.mybatis.myboard;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.mybatis.dto.FileBoardDTO;
import com.mybatis.model.BoardService;

@RequestMapping("/file/*")
@Controller
public class FileController {

	@Autowired
	BoardService service;

	@GetMapping("uploadForm")
	public void uploadForm() {

	}

	@PostMapping("fileAction")
	public String upload(MultipartFile[] uploads, Model model) {
		String uploadFolder = "D:\\Workspace\\Spring_ws\\Board_Mybatis\\src\\main\\resources";
		ArrayList<String> arr = new ArrayList<String>();

		for (MultipartFile multipart : uploads) {
			// System.out.println(multipart.getOriginalFilename());
			// ���� �̸� �ߺ� ���ϱ����� �̸� ����
			UUID uuid = UUID.randomUUID();
			String uploadFileName = uuid.toString() + "_" + multipart.getOriginalFilename();
			System.out.println(uploadFileName);
			File saveFile = new File(uploadFolder, uploadFileName);
			try {
				multipart.transferTo(saveFile);
				arr.add(multipart.getOriginalFilename());
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
			model.addAttribute("uploadFileName", arr);
		}
		return "file/fileResult";
	}

	@GetMapping("fileInsert")
	public String insert() {
		return "file/fileboardInsert";
	}

	@PostMapping("fileInsert")
	public String insert(FileBoardDTO filedto, HttpSession session, Model model) {

		String uploadFoler = session.getServletContext().getRealPath("/") + "\\resources\\upload";
		UUID uuid = UUID.randomUUID();
		MultipartFile multipartfile = filedto.getUpload();
		String uploadFileName = "";

		if (!multipartfile.isEmpty()) {
			uploadFileName = uuid.toString() + "_" + multipartfile.getOriginalFilename();
			File saveFile = new File(uploadFoler, uploadFileName);

			try {
				multipartfile.transferTo(saveFile); // ���� ���ε�
				filedto.setFileImage(uploadFileName); // DB
			} catch (IllegalStateException | IOException e) {

				e.printStackTrace();
			}
		}

		// ���� �̸��� DB�� ���� ��
		service.fileInsert(filedto);

		return "redirect:fileList";
	}

	@GetMapping("fileList")
	public String fileList(Model model) {
		List<FileBoardDTO> file_list = service.fileList();
		model.addAttribute("files", file_list);
		return "file/fileList";
	}
}
