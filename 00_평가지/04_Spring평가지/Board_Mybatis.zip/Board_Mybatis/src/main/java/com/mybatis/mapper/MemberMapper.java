package com.mybatis.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.mybatis.dto.MemberDTO;

public interface MemberMapper {

	@Insert("insert into member (id, name, addr, password) values (#{id}, #{name}, #{addr}, #{password}) ")
	public void join(MemberDTO member);

	@Select("select count(*) from member where id = #{id}")
	public int idCheck(String id);

	@Select("select * from member where id= #{id}")
	public MemberDTO loginCheck(String id);

	@Update("update member set name=#{name}, password=#{password}, addr=#{addr}, regdate=now() where id = #{id}")
	public int updateAcc(MemberDTO member);

	@Delete("delete from member where id = #{id}")
	public int deleteAcc(String id);
}