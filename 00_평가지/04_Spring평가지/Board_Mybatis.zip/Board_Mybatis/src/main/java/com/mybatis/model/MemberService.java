package com.mybatis.model;

import com.mybatis.dto.MemberDTO;

public interface MemberService {
	public void join(MemberDTO member);

	public int idCheck(String id);

	public MemberDTO loginCheck(String id);

	public int updateAcc(MemberDTO member);

	public int deleteAcc(String id);
}
